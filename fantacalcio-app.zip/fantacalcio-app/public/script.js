document.addEventListener('DOMContentLoaded', () => {
  let players = [];
  let currentSort = { column: 'price', direction: 'desc' };
  
  // Gestione caricamento file
  document.getElementById('loadPlayers').addEventListener('click', () => {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];
    
    if (!file) {
      document.getElementById('fileStatus').innerHTML = '<p class="text-red-400">Seleziona un file JSON prima di caricare.</p>';
      return;
    }
    
    document.getElementById('fileStatus').innerHTML = '<p><span class="loader"></span>Caricamento in corso...</p>';
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        players = JSON.parse(e.target.result);
        populatePlayerSelects(players);
        renderPlayersTable(players);
        enableButtons();
        document.getElementById('fileStatus').innerHTML = `<p class="text-green-400">Caricati ${players.length} giocatori con successo!</p>`;
      } catch (error) {
        console.error('Errore nel parsing del JSON:', error);
        document.getElementById('fileStatus').innerHTML = '<p class="text-red-400">Errore nel parsing del file JSON. Assicurati che il file sia valido.</p>';
      }
    };
    reader.onerror = () => {
      document.getElementById('fileStatus').innerHTML = '<p class="text-red-400">Errore nella lettura del file.</p>';
    };
    reader.readAsText(file);
  });
  
  // Popola i select dei giocatori
  function populatePlayerSelects(players) {
    const player1Select = document.getElementById('tradePlayer1');
    const player2Select = document.getElementById('tradePlayer2');
    
    // Pulisci le opzioni esistenti
    player1Select.innerHTML = '';
    player2Select.innerHTML = '';
    
    // Aggiungi opzione vuota
    const emptyOption = document.createElement('option');
    emptyOption.value = '';
    emptyOption.text = 'Seleziona Giocatore';
    player1Select.add(emptyOption);
    player2Select.add(emptyOption.cloneNode(true));
    
    // Aggiungi i giocatori
    players.forEach(p => {
      const option = document.createElement('option');
      option.value = p.name;
      option.text = `${p.name} (${p.role}, ${p.team})`;
      option.dataset.price = p.price || 0;
      option.dataset.fantamedia = p.fantamedia || 0;
      option.dataset.media = p.media || 0;
      option.dataset.team = p.team || 'N/A';
      option.dataset.role = p.role || 'N/A';
      player1Select.add(option.cloneNode(true));
      player2Select.add(option);
    });
    
    // Abilita i select
    player1Select.disabled = false;
    player2Select.disabled = false;
    
    // Aggiungi event listener per mostrare i dettagli
    player1Select.addEventListener('change', function() {
      showPlayerDetails(this, 'player1');
    });
    
    player2Select.addEventListener('change', function() {
      showPlayerDetails(this, 'player2');
    });
  }
  
  // Mostra i dettagli del giocatore selezionato
  function showPlayerDetails(selectElement, playerNum) {
    const detailsDiv = document.getElementById(`${playerNum}Details`);
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    
    if (selectedOption.value) {
      detailsDiv.classList.remove('hidden');
      document.getElementById(`${playerNum}Fantamedia`).textContent = selectedOption.dataset.fantamedia;
      document.getElementById(`${playerNum}Price`).textContent = selectedOption.dataset.price;
      document.getElementById(`${playerNum}Media`).textContent = selectedOption.dataset.media;
      document.getElementById(`${playerNum}Team`).textContent = selectedOption.dataset.team;
      document.getElementById(`${playerNum}Role`).textContent = selectedOption.dataset.role;
    } else {
      detailsDiv.classList.add('hidden');
    }
  }
  
  // Renderizza la tabella dei giocatori
  function renderPlayersTable(playersToRender) {
    const tableBody = document.getElementById('playersTableBody');
    tableBody.innerHTML = '';
    
    if (playersToRender.length === 0) {
      tableBody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-400">Nessun giocatore trovato</td></tr>';
      return;
    }
    
    playersToRender.forEach(p => {
      const row = document.createElement('tr');
      
      // Badge per il ruolo
      const roleBadge = `<span class="role-badge role-${p.role}">${p.role}</span>`;
      
      row.innerHTML = `
        <td class="font-medium">${p.name}</td>
        <td>${roleBadge}</td>
        <td>${p.team || 'N/A'}</td>
        <td>${p.media?.toFixed(1) || '0.0'}</td>
        <td>${p.fantamedia?.toFixed(1) || '0.0'}</td>
        <td class="font-bold">${p.price || '0'}</td>
      `;
      
      tableBody.appendChild(row);
    });
  }
  
  // Abilita i pulsanti dopo il caricamento
  function enableButtons() {
    document.getElementById('analyzeTrade').disabled = false;
  }
  
  // Aggiungi gestori eventi per le altre funzioni
  document.getElementById('analyzeTrade').addEventListener('click', async () => {
    const player1Select = document.getElementById('tradePlayer1');
    const player2Select = document.getElementById('tradePlayer2');
    const player1 = player1Select.value;
    const player2 = player2Select.value;
    
    if (!player1 || !player2) {
      alert('Seleziona entrambi i giocatori');
      return;
    }
    
    const player1Option = player1Select.options[player1Select.selectedIndex];
    const player2Option = player2Select.options[player2Select.selectedIndex];
    
    const price1 = parseFloat(player1Option.dataset.price) || 0;
    const price2 = parseFloat(player2Option.dataset.price) || 0;
    const fantamedia1 = parseFloat(player1Option.dataset.fantamedia) || 0;
    const fantamedia2 = parseFloat(player2Option.dataset.fantamedia) || 0;
    
    const diffPrice = price2 - price1;
    const diffFantamedia = fantamedia2 - fantamedia1;
    
    let analysisText = '';
    let overallVerdict = '';
    
    // Valutazione in base alla quotazione (prioritaria)
    if (diffPrice > 0) {
      analysisText += `Vantaggio economico: <span class="positive">+${diffPrice}FV</span>. `;
    } else if (diffPrice < 0) {
      analysisText += `Svantaggio economico: <span class="negative">${diffPrice}FV</span>. `;
    } else {
      analysisText += `Nessuna differenza economica. `;
    }
    
    // Valutazione in base alla fantamedia
    if (diffFantamedia > 0) {
      analysisText += `Vantaggio fantamedia: <span class="positive">+${diffFantamedia.toFixed(1)}</span>.`;
    } else if (diffFantamedia < 0) {
      analysisText += `Svantaggio fantamedia: <span class="negative">${diffFantamedia.toFixed(1)}</span>.`;
    } else {
      analysisText += `Nessuna differenza di fantamedia.`;
    }
    
    // Giudizio complessivo (priorità alla quotazione)
    if (diffPrice > 10) {
      overallVerdict = '<span class="positive">SCAMBIO MOLTO VANTAGGIOSO</span> (ottimo guadagno economico)';
    } else if (diffPrice > 0) {
      overallVerdict = '<span class="positive">SCAMBIO VANTAGGIOSO</span> (guadagno economico)';
    } else if (diffPrice === 0 && diffFantamedia > 0) {
      overallVerdict = '<span class="positive">SCAMBIO VANTAGGIOSO</span> (miglioramento fantamedia a parità di costo)';
    } else if (diffPrice < -10) {
      overallVerdict = '<span class="negative">SCAMBIO MOLTO SVANTAGGIOSO</span> (forte perdita economica)';
    } else if (diffPrice < 0) {
      overallVerdict = '<span class="negative">SCAMBIO SVANTAGGIOSO</span> (perdita economica)';
    } else {
      overallVerdict = 'SCAMBIO NEUTRO (nessun vantaggio significativo)';
    }
    
    document.getElementById('tradeOutput').innerHTML = `
      <p class="font-semibold">${analysisText}</p>
      <p class="mt-2"><span class="font-medium">Dettagli:</span> ${player1} (${price1} FV, FM:${fantamedia1.toFixed(1)}) → ${player2} (${price2} FV, FM:${fantamedia2.toFixed(1)})</p>
      <p class="mt-2 font-semibold text-lg">${overallVerdict}</p>
    `;
  });

  // Filtri per ruolo
  document.querySelectorAll('.filter-button').forEach(button => {
    button.addEventListener('click', function() {
      document.querySelectorAll('.filter-button').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      
      const role = this.dataset.role;
      let filteredPlayers = players;
      
      if (role !== 'all') {
        filteredPlayers = players.filter(p => p.role === role);
      }
      
      // Applica anche la ricerca se presente
      const searchTerm = document.getElementById('searchPlayer').value.toLowerCase();
      if (searchTerm) {
        filteredPlayers = filteredPlayers.filter(p => 
          p.name.toLowerCase().includes(searchTerm) || 
          p.team.toLowerCase().includes(searchTerm)
        );
      }
      
      renderPlayersTable(filteredPlayers);
    });
  });
  
  // Ricerca giocatori
  document.getElementById('searchPlayer').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const activeFilter = document.querySelector('.filter-button.active').dataset.role;
    
    let filteredPlayers = players;
    
    if (activeFilter !== 'all') {
      filteredPlayers = players.filter(p => p.role === activeFilter);
    }
    
    filteredPlayers = filteredPlayers.filter(p => 
      p.name.toLowerCase().includes(searchTerm) || 
      p.team.toLowerCase().includes(searchTerm)
    );
    
    renderPlayersTable(filteredPlayers);
  });
  
  // Ordinamento tabella
  document.querySelectorAll('.player-table th[data-sort]').forEach(header => {
    header.addEventListener('click', function() {
      const column = this.dataset.sort;
      
      if (currentSort.column === column) {
        currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
      } else {
        currentSort.column = column;
        currentSort.direction = 'asc';
      }
      
      // Aggiorna indicatori visivi
      document.querySelectorAll('.player-table th').forEach(th => {
        th.textContent = th.textContent.replace(' ▴', '').replace(' ▾', '');
      });
      
      this.textContent += currentSort.direction === 'asc' ? ' ▴' : ' ▾';
      
      // Ordina i giocatori
      const sortedPlayers = [...players].sort((a, b) => {
        let valueA = a[column] || 0;
        let valueB = b[column] || 0;
        
        // Gestione valori stringa
        if (typeof valueA === 'string') {
          valueA = valueA.toLowerCase();
          valueB = valueB.toLowerCase();
        }
        
        if (valueA < valueB) return currentSort.direction === 'asc' ? -1 : 1;
        if (valueA > valueB) return currentSort.direction === 'asc' ? 1 : -1;
        return 0;
      });
      
      renderPlayersTable(sortedPlayers);
    });
  });
});