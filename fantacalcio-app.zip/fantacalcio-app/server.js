const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs').promises;
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static('public'));

const playersFile = path.join(__dirname, 'data', 'players.json');

async function loadPlayers() {
  try {
    const data = await fs.readFile(playersFile, 'utf8');
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
}

async function savePlayers(players) {
  await fs.writeFile(playersFile, JSON.stringify(players, null, 2));
}

app.get('/getPlayers', async (req, res) => {
  const players = await loadPlayers();
  res.json(players);
});

app.get('/recommendFormation', async (req, res) => {
  const modificatore = req.query.modificatore === 'true';
  const opponent = req.query.opponent || '';
  const players = await loadPlayers();

  // Hard-coded strong teams for opponent logic
  const strongTeams = ['Inter', 'Juventus', 'Milan', 'Napoli', 'Roma', 'Atalanta', 'Fiorentina', 'Lazio'];
  const isStrongOpponent = strongTeams.includes(opponent.charAt(0).toUpperCase() + opponent.slice(1).toLowerCase());

  let module, numD, numC, numA;
  if (modificatore && isStrongOpponent) {
    module = '5-3-2';
    numD = 5;
    numC = 3;
    numA = 2;
  } else if (modificatore) {
    module = '4-4-2';
    numD = 4;
    numC = 4;
    numA = 2;
  } else if (isStrongOpponent) {
    module = '4-5-1';
    numD = 4;
    numC = 5;
    numA = 1;
  } else {
    module = '3-4-3';
    numD = 3;
    numC = 4;
    numA = 3;
  }

  // Sort by fantamedia or price descending
  const sortKey = p => p.fantamedia || p.price || 0;
  const sortedP = players.filter(p => p.role === 'P').sort((a, b) => sortKey(b) - sortKey(a));
  const sortedD = players.filter(p => p.role === 'D').sort((a, b) => sortKey(b) - sortKey(a));
  const sortedC = players.filter(p => p.role === 'C').sort((a, b) => sortKey(b) - sortKey(a));
  const sortedA = players.filter(p => p.role === 'A').sort((a, b) => sortKey(b) - sortKey(a));

  const selectedP = sortedP.slice(0, 1).map(p => p.name);
  const selectedD = sortedD.slice(0, numD).map(p => p.name);
  const selectedC = sortedC.slice(0, numC).map(p => p.name);
  const selectedA = sortedA.slice(0, numA).map(p => p.name);

  const selectedPlayers = [...selectedP, ...selectedD, ...selectedC, ...selectedA];

  res.json({ module, players: selectedPlayers });
});

app.get('/analyzeTrade', async (req, res) => {
  const { player1, player2 } = req.query;
  const players = await loadPlayers();
  const p1 = players.find(p => p.name === player1);
  const p2 = players.find(p => p.name === player2);

  if (!p1 || !p2) {
    return res.json({ result: 'Giocatore non trovato' });
  }

  const score1 = p1.fantamedia || p1.price;
  const score2 = p2.fantamedia || p2.price;
  const diff = score1 - score2;
  const result = diff > 0 ? `${player1} è migliore di ${player2} (punteggio: ${score1} vs ${score2})` : `${player2} è migliore di ${player1} (punteggio: ${score2} vs ${score1})`;
  res.json({ result });
});

app.get('/fetchPrices', async (req, res) => {
  const players = await loadPlayers();
  const prices = players.map(p => ({
    name: p.name,
    role: p.role,
    team: p.team,
    price: p.price
  }));
  res.json(prices);
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));