import json
import pandas as pd
from pathlib import Path

# Percorsi
base_dir = Path.home() / "mattia" / "fantacalcio-app"
excel_file = base_dir / "Quotazioni_Fantacalcio_Stagione_2025_26.xlsx"
json_file = base_dir / "data" / "players.json"

# Carica Excel
df = pd.read_excel(excel_file)

# Normalizza i nomi delle colonne (alcune versioni del listone hanno spazi o maiuscole)
df.columns = [c.strip().lower() for c in df.columns]

# Creazione lista giocatori
players = []
for _, row in df.iterrows():
    player = {
        "name": row.get("nome", ""),
        "team": row.get("squadra", ""),
        "role": row.get("ruolo", ""),
        "quotazione": int(row.get("quotazione iniziale", 0) / 2),  # dimezzata (da 1000 a 500)
        "media_voto": row.get("mv", 0),
        "fantamedia": row.get("fm", 0)
    }
    players.append(player)

# Salva su JSON
with open(json_file, "w", encoding="utf-8") as f:
    json.dump(players, f, ensure_ascii=False, indent=2)

print(f"Aggiornato {json_file} con {len(players)} giocatori.")
